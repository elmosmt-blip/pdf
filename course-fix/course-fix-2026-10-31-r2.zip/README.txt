COURSE FIX BUNDLE — ROUND 2 (2026-10-31)
Systematic verification pass over all 92 lessons and all 185 questions.

WHAT THIS BUNDLE IS
-------------------
Round 1 (course-fix-2026-10-31.zip) was built from a spot-check of about ten
worked examples. A later full pass over every lesson and every question showed
that several defects were module-wide rather than local, and that a number of
quiz questions grade the learner against a wrong rule of thumb. This bundle is
the corrected data plus the script that produced it.

FILES
-----
  data/lessons.fixed.json      92 lessons, patched (845,092 bytes)
  data/questions.fixed.json    185 questions, patched (230,569 bytes)
  data/sources.fixed.json      17 sources (525,384 -> 5,254 bytes)
  assets/data-embed.fixed.js   embedded snapshot for the file:// runtime
                               (979,350 bytes) — MUST be replaced together
                               with the JSON files or the offline runtime
                               serves stale content.
  scripts/apply-review-fixes.js        round-1 fixes (unchanged)
  scripts/apply-verification-fixes.js  round-2 fixes (new)
  scripts/check-course.js, embed.js, gates.js  validators

HOW TO APPLY
------------
  1. Replace course/data/lessons.json, questions.json, sources.json with the
     three *.fixed.json files.
  2. Replace course/assets/data-embed.js with assets/data-embed.fixed.js,
     or run `node scripts/embed.js` after step 1 to regenerate it.
  3. Copy scripts/apply-verification-fixes.js into course/scripts/ so the
     patch is reproducible from the original files.
  4. Run `node scripts/check-course.js` and `node scripts/gates.js`.
     Expected: check-course OK; gates OK with 185 questions, 92 lessons,
     17 sources and G-COMP/G-QUIZ passed.

The patch script is idempotent and guarded: every fix is an exact-string
replacement, and it fails loudly if the expected source text is not found.
Re-running it on already-patched data reports "already applied" for all 47
actions and exits 0.

WHAT CHANGED IN ROUND 2 (47 actions)
------------------------------------
V1  J-STD-020 / J-STD-033 confusion. Floor life was attributed to J-STD-020
    and quoted at 85% RH; the J-STD-033 reference condition is 30 C / 60% RH.
    Fixed in m02l02, m02l06 (theory and worked example) and q-m02l01-02.
V2  J-STD-033 bake table. "45 C for 72 h" for tape and reel and a "192 h
    standard bake for the highest MSL" are not table values. Bake time is
    indexed to package body thickness, and tape and reel is limited to 40 C
    (about 9-38 days). Fixed in m02l04 and q-m02l04-02.
V3  m03l04 quoted aperture area (0.121 mm^2) as a paste volume; the volume is
    area x foil thickness = 0.0121 mm^3.
V4  Time above liquidus attributed to J-STD-020 in five lessons and three
    questions. J-STD-020's own time parameter is tp, the time within 5 C of
    the classification temperature (30-40 s); the 60-150 s window is IPC-7530
    and paste-datasheet process guidance.
V5  J-STD-020 classification temperatures quoted as a single "245 C" or
    "245-250 C" figure. The standard classifies by package size: 260 C small,
    250 C large, 245 C very large.
V6  SAC305 liquidus quoted as 217 C in several places; 217 C is the solidus
    and the liquidus is 219 C. One lesson had the two swapped.
V7  IPC-A-610 hole fill: "Class 3 minimum of 100%" is not in the standard.
    Class 2 and Class 3 both require 75% minimum vertical barrel fill, with
    Class 3 additionally requiring fillets on both sides.
V8  Wave flux density quoted on a mg/cm2 basis that is 20-100x the industry
    figure. The controlled quantity is flux solids: 500-1500 ug/in2, which is
    0.08-0.23 mg/cm2 or about 0.8-2.3 g/m2. Fixed in m09l02, m09l03, m09l07
    and in three questions; m10l02 gained an explicit basis note so the
    selective-soldering figure is not confused with the wave-soldering one.
V9  q-m09l06-02 had an answer key that contradicted its own explanation and
    the arithmetic, plus a rule of thumb that added two diameters to estimate
    a fill height. Rewritten on the annular-area basis.
V10 q-m01l05-02 quoted a 95% in-range requirement for J-STD-005 Type 3
    powder; the requirement is 80% minimum between 25 and 45 um, which also
    changes the disposition of the worked example.
V11 q-m11l04-02 used a 0.10 mm Class 3 annular-ring minimum while its own
    lesson uses 0.05 mm.
V12 Cleanliness unit basis mixed: 1.56 ug/cm2 and 1.56 ug/in2 used
    interchangeably (they differ by a factor of 6.45), and a "Class 2 limit
    of 3.12 ug/cm2" that no source supports. The traditional ROSE level is
    1.56 ug/cm2 (about 10.06 ug/in2), quoted independently of product class,
    and J-STD-001 now requires objective evidence (SIR) rather than a single
    ROSE number.

NOT CHANGED, DELIBERATELY
-------------------------
  * Every lesson keeps status "draft" and its TBD-REVIEW marker. Promotion to
    reviewed/published stays a human action.
  * The three source ids added by this round (src-015 J-STD-005, src-016
    IPC-A-610H hole fill, src-017 J-STD-020 classification temperatures) keep
    edition/section/verifiedBy as TBD-REVIEW, matching the other 14.
  * Lesson schema, competency taxonomy and the auditor stage contract are
    untouched.
