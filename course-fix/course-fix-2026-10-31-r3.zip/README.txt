COURSE FIX BUNDLE — ROUND 3 (2026-10-31)
Cross-consistency pass over all 15 modules, 92 lessons and 185 questions.

WHAT THIS BUNDLE IS
-------------------
Rounds 1 and 2 verified each lesson and each question in isolation. This
round re-reads every module, lesson, question and answer and checks them
against each other and against the source standards. That is a different
class of defect: a number can be individually defensible and still
contradict the same number taught in a neighbouring lesson, a quiz can
grade the learner against a definition its own lesson contradicts, or a
citation can name a standard that does not cover the subject.

FILES
-----
  data/lessons.fixed.json      92 lessons, patched (847,968 bytes)
  data/questions.fixed.json    185 questions, patched (232,939 bytes)
  data/sources.fixed.json      17 sources (5,254 bytes)
  assets/data-embed.fixed.js   embedded snapshot for the file:// runtime
                               (984,596 bytes) — MUST be replaced together
                               with the JSON files or the offline runtime
                               serves stale content.
  scripts/apply-audit-fixes.js          round-3 fixes (new)
  scripts/apply-verification-fixes.js   round-2 fixes
  scripts/apply-review-fixes.js         round-1 fixes
  scripts/check-course.js, embed.js, gates.js  validators

HOW TO APPLY
------------
  1. Replace course/data/lessons.json, questions.json, sources.json with the
     three *.fixed.json files.
  2. Replace course/assets/data-embed.js with assets/data-embed.fixed.js,
     or run `node scripts/embed.js` after step 1 to regenerate it.
  3. Copy scripts/apply-audit-fixes.js into course/scripts/ so the patch is
     reproducible from the round-2.5 files.
  4. Run `node scripts/check-course.js` and `node scripts/gates.js`.
     Expected: check-course OK; gates OK with 185 questions, 92 lessons,
     17 sources and G-COMP/G-QUIZ passed.

The patch script is idempotent and guarded: every fix is an exact-string
replacement, and it fails loudly if the expected source text is not found.
Re-running it on already-patched data reports "already applied" for all 16
actions and exits 0.

WHAT CHANGED IN ROUND 3 (16 actions, 11 finding groups)
------------------------------------------------------
W1  m02l01 listed "MSL 6 12 h". J-STD-020/033 give MSL 6 no floor life at
    all — it is mandatory bake before use, with the post-bake reflow window
    taken from the label. The lesson also contradicted m02l02, m02l03 and
    m02l04, which all say MSL 6 requires bake before use.
W2  m02l06 theory quoted "125 C for 24 h" as a J-STD-033 high-temperature
    bake. Table 4-1 user-bake times at 125 C are indexed to package body
    thickness: 8 h up to 1.4 mm, 18 h for 1.4-2.0 mm, 48 h for
    2.0-4.5 mm. The 24 h figure is the supplier dry-pack condition
    (MET = 24 h), not a user bake, and it contradicted m02l04. The theory
    block now also states the 40 C column (about 9/11/38 days) and the
    96 h cumulative limit above 90 C.
W3  The same error inside the m02l06 worked example.
W4  The same error in q-m02l06-02, which graded the learner on a 24 h bake.
W5  m01l03 built an ISO 2859-1 plan as "code letter L, n = 80, Ac = 2,
    Re = 3". Code letter L is a sample of 200; at AQL 1.0% it is Ac = 5,
    Re = 6. The n = 80 / Ac = 2 / Re = 3 triple is code letter J, which is
    the level I letter for that lot band, not level II. Both module-01 quiz
    questions already used the correct values, so the lesson was the
    outlier. The theory now also states the level I and level III letters
    for the same lot band, which is where the confusion came from.
W6  q-m03l02-02 defined aspect ratio as stencil thickness / aperture width,
    the inverse of the definition in m03l02 and in q-m03l01-02, q-m03l04-02
    and q-m03l05-02. The worked values now use 0.10/0.12 = 0.83.
W7  q-m03l01-02 judged an area ratio of 0.25 against "the rule-of-thumb
    release threshold of 1.5"; 1.5 is the aspect-ratio rule of thumb, the
    area-ratio minimum is 0.66.
W8  m06l05 stated that nitrogen "does not change the SnAgCu liquidus of
    217 C"; the same lesson's first block correctly says solidus 217 C and
    liquidus 219 C.
W9  m09l07 step 8 set the wave pot temperature "above the SAC305 liquidus
    of 217 C"; 217 C is the solidus.
W10 m02l05 cited "ANSI/ESD STM97.7 and ANSI/ESD STM97.8" for ionizer
    qualification. Those documents do not cover ionization; the ESDA / IEC
    equivalency chart maps ionization to ANSI/ESD STM3.1 (IEC 61340-4-7),
    which the same sentence already named. STM97.1/97.2 are footwear and
    flooring, and are now named as such.
W11 m14l03 cited "IPC-7711/7712" twice; the rework pair used in the other
    sixteen lessons is IPC-7711/7721.

VERIFIED IN THIS PASS AND LEFT ALONE
------------------------------------
  * All 185 answer keys were re-derived from the prompt arithmetic; all
    are correct, including the fifteen rewritten in rounds 1-2.
  * Referential integrity is clean: every lesson quiz id resolves, every
    question lessonId resolves and links back, every cited source id
    exists, every question has exactly four options and the key is always
    among them (0 errors of any kind).
  * SAC305 solidus/liquidus is 217/219 C in every lesson; SnPb is 183 C.
  * Floor life by MSL is consistent in all five lessons that quote it.
  * J-STD-033 bake table (8/18/48 h at 125 C, about 9/11/38 days at 40 C,
    96 h cumulative above 90 C) is consistent across m02l04, m02l06 and
    the module-02 questions.
  * IPC-A-610 vertical barrel fill is 75% for both Class 2 and Class 3 in
    every lesson and question; the documented exception and the contractual
    100% requirement are both hedged.
  * Flux basis is flux solids, 500-1500 ug/in2 = 0.08-0.23 mg/cm2, in every
    wave-soldering lesson and question.
  * IPC-6012 bow/twist 0.75%, IPC-A-610 Class 3 annular ring 0.05 mm,
    J-STD-005 Type 3 powder 80% minimum between 25-45 um, IPC-CC-830
    coating thickness ranges and the ANSI/ESD S20.20 / IEC 61340-5-1 /
    STM3.1 / STM97.1-97.2 / S4.1 / STM11.11 citations were all checked
    against published sources and are correct.
  * Every lesson keeps status "draft" and its TBD-REVIEW marker; the three
    source ids added in round 2 keep their edition/section/verifiedBy
    TBD-REVIEW values. Promotion stays a human action.
