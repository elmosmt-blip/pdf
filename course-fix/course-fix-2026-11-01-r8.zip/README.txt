COURSE FIX BUNDLE — ROUND 4 (2026-10-31)
Audit of every table block and every SVG figure, plus module illustrations.

WHAT THIS BUNDLE IS
-------------------
Rounds 1-3 swept theory paragraphs, worked examples and quiz questions for bad
numbers, but they read theory[].p, content.calc and question objects — never
the table blocks inside theory[].blocks[] with t === "table". A pass over every
figure and table in the course therefore found numeric errors the earlier
sweeps could not see, and this bundle fixes them. It also adds the first
generated illustrations to the course, drawn in the course design system.

The bundle is a full copy of the running course, not a patch pack: the app
(app.js, style.css, index.html), the data, the illustrations and the scripts
are all included, so it can be dropped in place as-is.

FILES
-----
  index.html                     entry point (unchanged content)
  assets/app.js                  renderer — image intrinsic box synced to
                                 1280x896 to match CSS aspect-ratio 10/7
  assets/style.css               design system (unchanged)
  assets/data-embed.js           embedded snapshot for the file:// runtime
                                 (987,114 bytes) — MUST be replaced together
                                 with the JSON files or the offline runtime
                                 serves stale content.
  assets/img/mNN.png             module illustrations, 1280x896, one per module
  data/lessons.json              92 lessons, patched (851,206 bytes)
  data/questions.json            185 questions, patched (232,939 bytes)
  data/sources.json              17 sources (5,254 bytes)
  data/*.fixed.json              the same three files under the Drive upload
                                 names, so the bundle can be dropped into a
                                 course/data/ directory that already holds the
                                 round-1..3 *.fixed.json set
  scripts/apply-review-fixes.js        round-1 fixes (unchanged)
  scripts/apply-verification-fixes.js  round-2 fixes (unchanged)
  scripts/apply-audit-fixes.js         round-3 fixes (unchanged)
  scripts/apply-table-fixes.js         round-4 table/SVG audit fixes (new)
  scripts/apply-course-images.js       round-4 illustration wiring (new)
  scripts/check-course.js, embed.js, gates.js  validators

HOW TO APPLY
------------
  1. Copy the whole bundle over course/ — index.html, assets/ and data/. The
     data/ directory ships both names (lessons.json for the running app and
     lessons.fixed.json for the Drive upload set), so nothing has to be
     renamed.
  2. If you keep the JSON files separate from the app instead, run
     `node scripts/embed.js` to regenerate course/assets/data-embed.js from
     whatever JSON files are in place. The snapshot in this bundle already
     matches the bundled JSON.
  3. Copy scripts/apply-table-fixes.js and scripts/apply-course-images.js
     into course/scripts/ so both patches stay reproducible.
  4. Run `node scripts/check-course.js` and `node scripts/gates.js`.
     Expected: check-course OK; gates OK with 185 questions, 92 lessons,
     17 sources and G-COMP/G-QUIZ passed.

Both patch scripts are idempotent and guarded: every fix is an exact-string
replacement, and each fails loudly if the expected source text is not found.
Re-running on already-patched data reports "already applied" and exits 0.

WHAT CHANGED IN ROUND 4
-----------------------
Table and SVG audit — 15 SVG figures, 10 tables:
  * All 15 SVGs audited: every one uses the course design tokens (#0D1117,
    #53d1cc, #94a3b8, #edf2f7, #f44336, #ff9800, IBM Plex Mono) and carries a
    viewBox, so it scales correctly. Every numeric label is either correct
    (area ratio >= 0.66, Cp = (USL-LSL)/6 sigma, MSL 2/3 = 1 yr / 168 h, the
    Pareto shares 32/24/18/10/8/8 summing to 100%) or explicitly marked
    illustrative TBD-REVIEW. No SVG change was needed.
  * 8 of the 10 tables audited and cleared: m02l01 floor life, m08l01,
    m10l01, m11l01, m13l01, m14l01, m12l01 IPC-CC-830 chemistries, m15l01
    Cp/Cpk thresholds.

W12 m01l03 ISO 2859-1 code-letter table shifted by one lot band. It listed
    501-1200 as J/K/L, 1201-3200 as K/L/M and 3201-10000 as L/M/N. Table I of
    ANSI/ASQ Z1.4 / ISO 2859-1 gives 501-1200 as G(32)/J(80)/K(125),
    1201-3200 as H(50)/K(125)/L(200) and 3201-10000 as J(80)/L(200)/M(315).
    For a lot of 3201-10000 at level II the code letter is L, n = 200,
    Ac = 5, Re = 6 at AQL 1.0%. This table was the origin of the error that
    round 3 fixed in the m01l03 text (W5) but left in the table. Confirmed
    against four independent sources, including the lot-of-5000 case: level
    I = 80, level II = 200, level III = 315. The lesson's text, worked
    example, quiz and table now all agree.
W13 m06l01 profile table: "Liquidus 217 C" -> 219 C. 217 C is the SAC305
    solidus; the liquidus is 219 C, which every other lesson in the course
    already says.
W14 m06l01 profile table: "<= 2 C/s ramp" -> "1-3 C/s ramp", so the table
    matches m06l02 and the module-06 questions, which both teach 1-3 C/s.
W15 m02l01 floor-life table, MSL 6 row: "Solder within 24 h of bag open" ->
    "No floor life: bake before use, reflow within the label limit". J-STD-020
    gives MSL 6 no floor life and puts the post-bake reflow window on the
    label; a fixed 24 h is an invented limit.
W16 m14l03 defect.action: "rework per IPC-7711/7712" -> IPC-7711/7721. Round 3
    W11 corrected this lesson's theory and calc but not its defect block —
    the partial-coverage failure mode recurred. A sweep over every field of
    all 92 lessons found this fourth occurrence; the standard is IPC-7711/7721.

Module illustrations
  One generated illustration per module in assets/img/, attached as
  { t:'image', src, alt, caption } to the module-opening lesson, immediately
  after that lesson's SVG schematic, so the schematic keeps its position.
  Every illustration is drawn in the course design system extracted from
  style.css: background #0D1117, single signal teal #53d1cc, slate hairlines,
  translucent dark glass panels with 14/20/28 px radii, IBM Plex Mono labels,
  1280x896.

  Every number shown in an illustration is dictated explicitly, not left to
  the model. The first m01 came out with n = 32, Ac = 1, Re = 3 and was
  regenerated; m03 came out with an area-ratio range of 0.50-1.00 and was
  regenerated. Verified values: m01 lot 5,000, level II, AQL 1.0%, code L,
  n = 200, Ac = 5, Re = 6; m03 area ratio >= 0.66, aspect ratio >= 1.5;
  m06 liquidus 219 C / solidus 217 C, ramp 1-3 C/s, cooling 1-4 C/s,
  TAL 30-60 s; m08 75% vertical barrel fill for Class 2 and Class 3, annular
  ring 0.05 mm.

Renderer fix
  app.js declared <img width="1280" height="720"> while style.css sets
  .fig--photo img{aspect-ratio:10/7;object-fit:cover}. The intrinsic box is
  now 1280x896 to match the CSS ratio, and every image file is normalized to
  exactly 1280x896 so object-fit:cover neither crops nor stretches.

NOT CHANGED, DELIBERATELY
-------------------------
  * Every lesson keeps status "draft" and its TBD-REVIEW marker. Promotion to
    reviewed/published stays a human action.
  * Lesson schema, competency taxonomy and the auditor stage contract are
    untouched. The 12 m14/m15 lessons with stageId null and the two auditor
    stages with no course module are still reported by gates.js.
  * The illustrations are decorative support for the text; the lesson text
    and the quiz remain the single source of the numbers.
