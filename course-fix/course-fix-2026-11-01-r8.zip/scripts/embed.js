#!/usr/bin/env node
'use strict';
/*
 * embed.js — generate assets/data-embed.js from the three data JSON files.
 *
 * Why: the course must work from file:// where fetch() of local JSON is
 * blocked. app.js tries fetch('data/lessons.json') first (http) and falls
 * back to the global COURSE_DATA defined by this generated file.
 *
 * Output (exact shape, classic script so file:// can load it):
 *   var COURSE_DATA={"lessons":[...],"questions":[...],"sources":[...]};
 *
 * The payload is JSON.stringify of the parsed JSON files: no field is added,
 * renamed or dropped, so the embedded copy is content-identical to data/*.json
 * (asserted by tests/embed.test.js). Re-run this script after editing data.
 *
 * Usage:
 *   node scripts/embed.js [dataDir] [outFile]
 *
 * Exit code 0 = written, 1 = could not read/parse a data file.
 */

const fs = require('fs');
const path = require('path');

const FILES = { lessons: 'lessons.json', questions: 'questions.json', sources: 'sources.json' };

function fail(msg) {
  console.error('embed: ' + msg);
  process.exit(1);
}

function readJsonArray(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    fail('cannot read ' + file + ': ' + e.message);
  }
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    fail('invalid JSON in ' + file + ': ' + e.message);
  }
  if (!Array.isArray(data)) fail(file + ' must contain a JSON array');
  return data;
}

function main() {
  const dataDir = process.argv[2]
    ? path.resolve(process.argv[2])
    : path.join(__dirname, '..', 'data');
  const outFile = process.argv[3]
    ? path.resolve(process.argv[3])
    : path.join(__dirname, '..', 'assets', 'data-embed.js');

  const payload = {
    lessons: readJsonArray(path.join(dataDir, 'lessons.json')),
    questions: readJsonArray(path.join(dataDir, 'questions.json')),
    sources: readJsonArray(path.join(dataDir, 'sources.json'))
  };

  // JSON.stringify only: keeps key order and content identical to the source.
  const body = 'var COURSE_DATA=' + JSON.stringify(payload) + ';\n';

  try {
    fs.mkdirSync(path.dirname(outFile), { recursive: true });
    fs.writeFileSync(outFile, body, 'utf8');
  } catch (e) {
    fail('cannot write ' + outFile + ': ' + e.message);
  }

  console.log(
    'embed: wrote ' + outFile + ' (' +
    payload.lessons.length + ' lessons, ' +
    payload.questions.length + ' questions, ' +
    payload.sources.length + ' sources, ' +
    Buffer.byteLength(body, 'utf8') + ' bytes)'
  );
}

main();
