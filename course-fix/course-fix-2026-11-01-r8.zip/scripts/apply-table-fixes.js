#!/usr/bin/env node
'use strict';
/*
 * apply-table-fixes.js — fourth fix round (figures and tables).
 *
 * Rounds 1-3 swept theory paragraphs, worked examples and quiz questions for
 * bad numbers, but the sweeps read theory[].p and content.calc, never the
 * table blocks inside theory[].blocks[]. A pass over every figure and table
 * in the course found two numeric errors that the earlier sweeps could not
 * see, plus one internal inconsistency.
 *
 * Findings addressed (see COURSE_FIXES.md for the full audit):
 *   W12 m01l03's ISO 2859-1 code-letter table is shifted by one row: it
 *       lists 501-1200 as J/K/L, 1201-3200 as K/L/M and 3201-10000 as L/M/N.
 *       Table I of ANSI/ASQ Z1.4 / ISO 2859-1 gives 501-1200 as G/J/K,
 *       1201-3200 as H/K/L and 3201-10000 as J/L/M, with sample sizes
 *       G=32, H=50, J=80, K=125, L=200, M=315, N=500. This table was the
 *       source of the round-3 W5 error: it disagrees with the lesson text
 *       and with q-m01l03-02, both of which are correct.
 *   W13 m06l01's profile table lists "Liquidus 217 C". 217 C is the SAC305
 *       solidus; the liquidus is 219 C. Every other lesson in the course
 *       says 219 C.
 *   W14 m06l01's profile table caps the preheat ramp at "<= 2 C/s" while
 *       m06l02 teaches a 1-3 C/s ramp and the module-06 questions grade
 *       against 1-3 C/s.
 *   W15 m02l01's floor-life table gives MSL 6 as "Solder within 24 h of bag
 *       open". J-STD-020 gives MSL 6 no floor life at all and puts the
 *       post-bake reflow window on the label, so a fixed 24 h is an
 *       invented limit.
 *   W16 m14l03's defect.action still carries the transposed document number
 *       "IPC-7711/7712". Round 3 W11 corrected that lesson's theory and
 *       calc but not its defect block; a sweep over all fields found this
 *       fourth occurrence. The standard is IPC-7711/7721.
 *
 * The 15 inline SVG figures were also audited: every numeric label in them
 * is either correct (area ratio >= 0.66, Cp = (USL-LSL)/6 sigma, MSL 2/3 =
 * 1 yr / 168 h) or explicitly marked illustrative TBD-REVIEW, and all of
 * them use the course design tokens (#0D1117, #53d1cc, #94a3b8, #edf2f7,
 * #f44336, #ff9800, IBM Plex Mono). No changes were needed there.
 *
 * Usage: node scripts/apply-table-fixes.js [dataDir]
 */

const fs = require('fs');
const path = require('path');

const dataDir = process.argv[2] ? path.resolve(process.argv[2]) : path.join(__dirname, '..', 'data');
const FILES = {
  lessons: path.join(dataDir, 'lessons.json'),
  questions: path.join(dataDir, 'questions.json'),
  sources: path.join(dataDir, 'sources.json'),
};

const log = [];
function note(msg) { log.push(msg); console.log('  ' + msg); }

function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n', 'utf8');
}
function findLesson(lessons, id) {
  const l = lessons.find(function (x) { return x.lessonId === id; });
  if (!l) throw new Error('lesson not found: ' + id);
  return l;
}
// Returns the first theory block object whose `t` matches. Theory entries are
// {h, p, blocks:[…]}; the blocks array holds the table and figure objects.
function findBlock(lesson, t) {
  for (const sec of (lesson.content.theory || [])) {
    if (!sec || typeof sec !== 'object') continue;
    for (const b of (sec.blocks || [])) {
      if (b && b.t === t) return b;
    }
  }
  throw new Error('block not found: ' + lesson.lessonId + ' / ' + t);
}
function applyReplace(label, subject, from, to) {
  if (subject.indexOf(to) !== -1) { note('skip ' + label + ' (already applied)'); return subject; }
  const i = subject.indexOf(from);
  if (i === -1) throw new Error('FIX ' + label + ': expected source text not found');
  note('FIX ' + label);
  return subject.slice(0, i) + to + subject.slice(i + from.length);
}

function main() {
  console.log('apply-table-fixes: dataDir=' + dataDir);
  const lessons = readJson(FILES.lessons);
  const questions = readJson(FILES.questions);
  const sources = readJson(FILES.sources);

  // =====================================================================
  // W12 — ISO 2859-1 code letters (m01l03 table)
  // =====================================================================
  const m01l03 = findLesson(lessons, 'm01l03');
  const codeTable = findBlock(m01l03, 'table');
  // The caption guard accepts both forms so the script is re-runnable after
  // it has already rewritten the caption once.
  if (codeTable.caption.indexOf('sample size code letters') === -1 ||
      codeTable.caption.indexOf('ISO 2859-1') === -1) {
    throw new Error('W12: unexpected caption: ' + codeTable.caption);
  }
  const expectedOld = [
    ['501 - 1200', 'J (80 pcs)', 'K (125 pcs)', 'L (200 pcs)'],
    ['1201 - 3200', 'K (125 pcs)', 'L (200 pcs)', 'M (315 pcs)'],
    ['3201 - 10000', 'L (200 pcs)', 'M (315 pcs)', 'N (500 pcs)'],
  ];
  if (JSON.stringify(codeTable.rows) !== JSON.stringify(expectedOld)) {
    // Re-running after a partial application must not corrupt the table.
    note('skip W12 m01l03 rows (already applied or source data changed)');
  } else {
  note('FIX W12 m01l03 ISO 2859-1 code letters shifted by one row');
  codeTable.rows = [
    ['501 - 1200', 'G (32 pcs)', 'J (80 pcs)', 'K (125 pcs)'],
    ['1201 - 3200', 'H (50 pcs)', 'K (125 pcs)', 'L (200 pcs)'],
    ['3201 - 10000', 'J (80 pcs)', 'L (200 pcs)', 'M (315 pcs)'],
  ];
  }
  codeTable.caption = applyReplace(
    'W12 m01l03 code-letter caption',
    codeTable.caption,
    'sample size code letters (ISO 2859-1, lot 501-1200 units)',
    'sample size code letters (ISO 2859-1 / ANSI/ASQ Z1.4 Table I)'
  );

  // =====================================================================
  // W13/W14 — SAC305 profile envelope (m06l01 table)
  // =====================================================================
  const m06l01 = findLesson(lessons, 'm06l01');
  const profileTable = findBlock(m06l01, 'table');
  if (profileTable.caption.indexOf('Typical SAC305 profile envelope') === -1) {
    throw new Error('W13: unexpected caption: ' + profileTable.caption);
  }
  for (let i = 0; i < profileTable.rows.length; i++) {
    const row = profileTable.rows[i];
    if (row[0] === 'Preheat' && row[1] === '<= 2 C/s ramp') {
      note('FIX W14 m06l01 preheat ramp limit aligned with m06l02');
      row[1] = '1-3 C/s ramp';
    }
    if (row[0] === 'Reflow / peak' && row[1] === 'Liquidus 217 C, peak 235-245 C') {
      note('FIX W13 m06l01 liquidus 217 C -> 219 C');
      row[1] = 'Liquidus 219 C, peak 235-245 C';
    }
  }
  if (profileTable.rows.some(function (r) { return /217 C/.test(r[1]); })) {
    throw new Error('W13: 217 C still present in the profile table');
  }

  // =====================================================================
  // W15 — MSL 6 post-bake window (m02l01 table)
  // =====================================================================
  const m02l01 = findLesson(lessons, 'm02l01');
  const mslTable = findBlock(m02l01, 'table');
  if (mslTable.caption.indexOf('J-STD-033 floor life') === -1) {
    throw new Error('W15: unexpected caption: ' + mslTable.caption);
  }
  for (let i = 0; i < mslTable.rows.length; i++) {
    if (mslTable.rows[i][0] === '6' && mslTable.rows[i][2] === 'Solder within 24 h of bag open') {
      note('FIX W15 m02l01 MSL 6 post-bake window is label-specific');
      mslTable.rows[i][2] = 'No floor life: bake before use, reflow within the label limit';
    }
  }

  // =====================================================================
  // W16 - transposed rework document number (m14l03 defect block)
  // =====================================================================
  const m14l03 = findLesson(lessons, 'm14l03');
  const defectText = m14l03.content.defect && m14l03.content.defect.action;
  if (typeof defectText !== 'string') {
    throw new Error('W16: m14l03 defect.action is missing');
  }
  if (defectText.indexOf('IPC-7711/7712') === -1) {
    note('skip W16 (already applied)');
  } else {
    m14l03.content.defect.action = defectText.split('IPC-7711/7712').join('IPC-7711/7721');
    note('FIX W16 m14l03 defect.action IPC-7711/7712 -> IPC-7711/7721');
  }

  writeJson(FILES.lessons, lessons);
  writeJson(FILES.questions, questions);
  writeJson(FILES.sources, sources);
  console.log('apply-table-fixes: done (' + log.length + ' actions).');
}

try { main(); } catch (e) {
  console.error('apply-table-fixes: FAILED — ' + e.message);
  process.exit(1);
}
