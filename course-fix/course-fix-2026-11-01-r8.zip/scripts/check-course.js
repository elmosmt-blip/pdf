#!/usr/bin/env node
'use strict';
/*
 * check-course.js — validates the three course data files against the
 * shared CONTRACT.md course schemas. Zero dependencies, classic CommonJS.
 *
 * Usage:
 *   node scripts/check-course.js [dataDir]
 *
 * dataDir defaults to ../data relative to this script. Pass a directory to
 * validate a different copy (used by the test suite).
 *
 * Exit code 0 = clean, 1 = one or more errors (each printed on its own line).
 */

const fs = require('fs');
const path = require('path');

// --- contract constants -----------------------------------------------------

// The 15 stable stage ids from CONTRACT.md ("Stage ids" section).
const STAGE_IDS = [
  'incoming', 'storage', 'stencil', 'print', 'placement', 'reflow', 'aoi',
  'tht-prep', 'wave', 'selective', 'manual-rework', 'coating-esd', 'test',
  'shipping', 'capability',
];

const STATUSES = ['draft', 'factchecked', 'reviewed', 'published'];
const QUESTION_TYPES = ['single', 'calc', 'classify', 'case'];
const COMPETENCIES = ['K1', 'K2', 'K3', 'K4', 'K5', 'K6', 'K7', 'K8', 'K9', 'K10'];

const MODULE_ID_RE = /^m\d{2}$/;
const LESSON_ID_RE = /^m\d{2}l\d{2}$/;

/*
 * Lesson content blocks (rendered by assets/app.js -> blockHtml).
 * content.sections = [{h?, blocks:[block]}] | content.blocks = [block]
 * A sections[] entry may itself be a block (it carries `t`).
 *
 *   {t:'p'|'h'|'h2'|'h3', text}
 *   {t:'ul'|'ol'|'steps', items:[string]}
 *   {t:'table', caption?, head:[string], rows:[[string]]}
 *   {t:'figure', svg:'<svg …</svg>', caption?}
 *   {t:'callout', kind:'note'|'warn'|'tip', title?, text:string|[string]}
 *
 * The number rule (see NUM_UNIT_RE below) walks every string in the lesson,
 * so table cells, callout text, figure captions and step items are covered by
 * it automatically — a "25 µm" in a table cell needs a src-… or TBD-REVIEW too.
 */
const BLOCK_TYPES = ['p', 'ul', 'ol', 'steps', 'h', 'h2', 'h3', 'table', 'figure', 'image', 'callout'];
const CALLOUT_KINDS = ['note', 'warn', 'tip'];
// The renderer only inserts figure.svg raw when the whole field is one <svg>.
const SVG_FIGURE_RE = /^<svg[\s\S]*<\/svg>$/;

/*
 * Number-with-unit heuristic (documented, intentionally simple):
 * CONTRACT.md says "Every number in content must cite src-... or be TBD-REVIEW".
 * We cannot parse prose perfectly, so we flag any string that looks like a
 * measurement: a digit immediately followed by a unit token (°C, mm, %, ...)
 * or a "±" immediately followed by a digit. When a lesson contains such a
 * string, the lesson must either reference at least one source OR contain the
 * literal "TBD-REVIEW" marker. This is a guard-rail, not a proof — it catches
 * the common "engineer typed a number and forgot to cite it" case.
 */
const UNIT_TOKENS = [
  '°C', '°F', '°', '%', 'µm', 'um', 'mm', 'cm', 'mil', 'psi', 'kPa', 'MPa',
  'ms', 'us', 'ns', 'nm', 'V', 'A', 'W', 's',
];
const NUM_UNIT_RE = new RegExp(
  '\\d[\\d.,]*\\s*(?:' + UNIT_TOKENS.join('|') + ')(?![A-Za-z0-9])' +
  '|±\\s*\\d'
);

// --- helpers ----------------------------------------------------------------

function readJson(file, errors) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    errors.push('cannot read ' + path.basename(file) + ': ' + e.message);
    return null;
  }
  try {
    return JSON.parse(raw);
  } catch (e) {
    errors.push('invalid JSON in ' + path.basename(file) + ': ' + e.message);
    return null;
  }
}

// Collect every string value reachable in an object/array graph.
function collectStrings(node, out) {
  if (typeof node === 'string') {
    out.push(node);
  } else if (Array.isArray(node)) {
    for (const v of node) collectStrings(v, out);
  } else if (node && typeof node === 'object') {
    for (const k of Object.keys(node)) collectStrings(node[k], out);
  }
  return out;
}

function isNonEmptyString(v) {
  return typeof v === 'string' && v.length > 0;
}

// A source counts as "verified" when a human has signed it off.
function sourceIsVerified(src) {
  return (
    src &&
    isNonEmptyString(src.verifiedBy) &&
    src.verifiedBy !== 'TBD-REVIEW' &&
    src.verifiedOn !== null &&
    src.verifiedOn !== undefined
  );
}

// --- content blocks ----------------------------------------------------------

function isStringList(v, minLen) {
  return (
    Array.isArray(v) &&
    v.length >= (minLen || 1) &&
    v.every(function (x) { return isNonEmptyString(x); })
  );
}

/**
 * Validate one block. `where` is the human-readable location used in messages
 * (e.g. "lesson m01l01 content.sections[0].blocks[2]").
 */
function validateBlock(block, where, errors) {
  if (typeof block === 'string') {
    if (!isNonEmptyString(block)) errors.push(where + ': empty string block');
    return;
  }
  if (!block || typeof block !== 'object' || Array.isArray(block)) {
    errors.push(where + ': block must be an object (or a string)');
    return;
  }
  if (BLOCK_TYPES.indexOf(block.t) === -1) {
    errors.push(where + ': block type "' + block.t + '" not in ' + BLOCK_TYPES.join('|'));
    return;
  }
  const t = block.t;

  if (t === 'p' || t === 'h' || t === 'h2' || t === 'h3') {
    const text = block.text !== undefined ? block.text : block.p;
    if (!isNonEmptyString(text)) errors.push(where + ' (' + t + '): needs a non-empty "text"');
    return;
  }

  if (t === 'ul' || t === 'ol' || t === 'steps') {
    if (!Array.isArray(block.items) || block.items.length < 1) {
      errors.push(where + ' (' + t + '): items must be a non-empty array');
      return;
    }
    block.items.forEach(function (it, i) {
      if (!isNonEmptyString(it)) errors.push(where + ' (' + t + ') items[' + i + ']: must be a non-empty string');
    });
    return;
  }

  if (t === 'table') {
    if (block.caption !== undefined && typeof block.caption !== 'string') {
      errors.push(where + ' (table): caption must be a string');
    }
    if (!isStringList(block.head, 1)) {
      errors.push(where + ' (table): head must be a non-empty array of strings');
      return;
    }
    if (!Array.isArray(block.rows) || block.rows.length < 1) {
      errors.push(where + ' (table): rows must be a non-empty array of arrays');
      return;
    }
    const n = block.head.length;
    block.rows.forEach(function (row, i) {
      if (!Array.isArray(row)) {
        errors.push(where + ' (table) rows[' + i + ']: must be an array of cells');
        return;
      }
      if (row.length !== n) {
        errors.push(where + ' (table) rows[' + i + ']: ' + row.length +
          ' cells but head has ' + n + ' (rows must match the head width)');
      }
      row.forEach(function (cell, j) {
        if (typeof cell !== 'string') {
          errors.push(where + ' (table) rows[' + i + '][' + j + ']: cell must be a string');
        }
      });
    });
    return;
  }

  if (t === 'figure') {
    if (!isNonEmptyString(block.svg)) {
      errors.push(where + ' (figure): svg must be a non-empty string');
    } else if (!SVG_FIGURE_RE.test(block.svg.trim())) {
      errors.push(where + ' (figure): svg must be one inline <svg …</svg> element ' +
        '(the renderer inserts it raw only when it matches /^<svg[\\s\\S]*<\\/svg>$/)');
    }
    if (block.caption !== undefined && typeof block.caption !== 'string') {
      errors.push(where + ' (figure): caption must be a string');
    }
    return;
  }

  if (t === 'image') {
    if (!isNonEmptyString(block.src)) {
      errors.push(where + ' (image): src must be a non-empty string');
    } else if (/^\s*javascript:/i.test(block.src)) {
      errors.push(where + ' (image): src must not be a javascript: URL');
    }
    if (block.caption !== undefined && typeof block.caption !== 'string') {
      errors.push(where + ' (image): caption must be a string');
    }
    if (block.alt !== undefined && typeof block.alt !== 'string') {
      errors.push(where + ' (image): alt must be a string');
    }
    return;
  }

  if (t === 'callout') {
    if (CALLOUT_KINDS.indexOf(block.kind) === -1) {
      errors.push(where + ' (callout): kind "' + block.kind + '" not in ' + CALLOUT_KINDS.join('|'));
    }
    if (Array.isArray(block.text)) {
      if (!isStringList(block.text, 1)) {
        errors.push(where + ' (callout): text array must hold non-empty strings');
      }
    } else if (!isNonEmptyString(block.text)) {
      errors.push(where + ' (callout): text must be a non-empty string (or array of strings)');
    }
    if (block.title !== undefined && typeof block.title !== 'string') {
      errors.push(where + ' (callout): title must be a string');
    }
  }
}

function validateBlocks(blocks, where, errors) {
  if (!Array.isArray(blocks)) {
    errors.push(where + ': must be an array of blocks');
    return;
  }
  blocks.forEach(function (b, i) { validateBlock(b, where + '[' + i + ']', errors); });
}

/** Walk every block-bearing place in lesson.content. */
function validateContentBlocks(lesson, errors) {
  const c = lesson.content;
  if (!c || typeof c !== 'object' || Array.isArray(c)) return;
  const id = isNonEmptyString(lesson.lessonId) ? lesson.lessonId : '<no lessonId>';

  if (c.sections !== undefined) {
    if (!Array.isArray(c.sections)) {
      errors.push('lesson ' + id + ' content.sections: must be an array');
    } else {
      c.sections.forEach(function (sec, i) {
        const where = 'lesson ' + id + ' content.sections[' + i + ']';
        if (!sec || typeof sec !== 'object') {
          errors.push(where + ': must be an object');
          return;
        }
        // A section entry may itself be a block, or a {h, blocks} wrapper.
        if (sec.t !== undefined) validateBlock(sec, where, errors);
        else if (sec.blocks !== undefined) validateBlocks(sec.blocks, where + '.blocks', errors);
      });
    }
  }

  if (c.blocks !== undefined) validateBlocks(c.blocks, 'lesson ' + id + ' content.blocks', errors);

  if (Array.isArray(c.theory)) {
    c.theory.forEach(function (th, i) {
      if (th && typeof th === 'object' && th.blocks !== undefined) {
        validateBlocks(th.blocks, 'lesson ' + id + ' content.theory[' + i + '].blocks', errors);
      }
    });
  }
}

// --- main -------------------------------------------------------------------

function main() {
  const dataDir = process.argv[2]
    ? path.resolve(process.argv[2])
    : path.join(__dirname, '..', 'data');

  const errors = [];

  const sources = readJson(path.join(dataDir, 'sources.json'), errors);
  const lessons = readJson(path.join(dataDir, 'lessons.json'), errors);
  const questions = readJson(path.join(dataDir, 'questions.json'), errors);

  // If any file failed to load we cannot cross-check; bail with what we have.
  if (sources === null || lessons === null || questions === null) {
    report(errors, dataDir);
    return;
  }
  for (const [name, arr] of [['sources.json', sources], ['lessons.json', lessons], ['questions.json', questions]]) {
    if (!Array.isArray(arr)) errors.push(name + ' must be a JSON array');
  }
  if (errors.length) { report(errors, dataDir); return; }

  // --- unique ids -----------------------------------------------------------
  const sourceIds = new Set();
  for (const s of sources) {
    if (!isNonEmptyString(s.id)) { errors.push('source missing id'); continue; }
    if (sourceIds.has(s.id)) errors.push('duplicate source id: ' + s.id);
    sourceIds.add(s.id);
  }

  const lessonIds = new Set();
  for (const l of lessons) {
    if (!isNonEmptyString(l.lessonId)) { errors.push('lesson missing lessonId'); continue; }
    if (lessonIds.has(l.lessonId)) errors.push('duplicate lessonId: ' + l.lessonId);
    lessonIds.add(l.lessonId);
  }

  const questionIds = new Set();
  for (const q of questions) {
    if (!isNonEmptyString(q.questionId)) { errors.push('question missing questionId'); continue; }
    if (questionIds.has(q.questionId)) errors.push('duplicate questionId: ' + q.questionId);
    questionIds.add(q.questionId);
  }

  // --- lessons --------------------------------------------------------------
  for (const l of lessons) {
    const id = isNonEmptyString(l.lessonId) ? l.lessonId : '<no lessonId>';

    if (!MODULE_ID_RE.test(String(l.moduleId || ''))) {
      errors.push('lesson ' + id + ': moduleId must match /^m\\d{2}$/ (got ' + JSON.stringify(l.moduleId) + ')');
    }
    if (!LESSON_ID_RE.test(String(l.lessonId || ''))) {
      errors.push('lesson ' + id + ': lessonId must match /^m\\d{2}l\\d{2}$/');
    }
    if (l.stageId !== undefined && l.stageId !== null && STAGE_IDS.indexOf(l.stageId) === -1) {
      errors.push('lesson ' + id + ': stageId "' + l.stageId + '" is not one of the 15 contract stage ids');
    }
    if (STATUSES.indexOf(l.status) === -1) {
      errors.push('lesson ' + id + ': status "' + l.status + '" not in ' + STATUSES.join('|'));
    }

    // >=1 goal, each with non-empty competencies drawn from K1..K10
    if (!Array.isArray(l.goals) || l.goals.length < 1) {
      errors.push('lesson ' + id + ': must have at least one goal');
    } else {
      l.goals.forEach(function (g, i) {
        if (!g || !Array.isArray(g.competencies) || g.competencies.length < 1) {
          errors.push('lesson ' + id + ' goal[' + i + ']: competencies must be non-empty');
          return;
        }
        for (const c of g.competencies) {
          if (COMPETENCIES.indexOf(c) === -1) {
            errors.push('lesson ' + id + ' goal[' + i + ']: competency "' + c + '" not in K1..K10');
          }
        }
      });
    }

    // every source ref exists
    const refs = Array.isArray(l.sources) ? l.sources : [];
    if (!Array.isArray(l.sources)) errors.push('lesson ' + id + ': sources must be an array');
    for (const ref of refs) {
      if (!sourceIds.has(ref)) errors.push('lesson ' + id + ': unknown source ref "' + ref + '"');
    }

    // quiz ids exist
    if (!Array.isArray(l.quiz)) {
      errors.push('lesson ' + id + ': quiz must be an array');
    } else {
      for (const qid of l.quiz) {
        if (!questionIds.has(qid)) errors.push('lesson ' + id + ': quiz references unknown question "' + qid + '"');
      }
    }

    // rich content blocks (table / figure / callout / steps / lists / headings)
    validateContentBlocks(l, errors);

    // number-with-unit heuristic
    const strings = collectStrings(l, []);
    const hasMeasurement = strings.some(function (s) { return NUM_UNIT_RE.test(s); });
    const hasTbd = strings.some(function (s) { return s.indexOf('TBD-REVIEW') !== -1; });
    if (hasMeasurement && refs.length < 1 && !hasTbd) {
      errors.push('lesson ' + id + ': contains a number-with-unit value but references no source and has no TBD-REVIEW marker');
    }

    // published lessons: status chain respected + no TBD-REVIEW anywhere
    if (l.status === 'published') {
      const blob = JSON.stringify(l);
      if (blob.indexOf('TBD-REVIEW') !== -1) {
        errors.push('lesson ' + id + ': published lesson must not contain "TBD-REVIEW"');
      }
      // Status chain: content may only be published once every source it
      // depends on has been human-verified (verifiedBy set + verifiedOn set).
      for (const ref of refs) {
        const src = sources.find(function (s) { return s && s.id === ref; });
        if (src && !sourceIsVerified(src)) {
          errors.push('lesson ' + id + ': published but source "' + ref + '" is not verified (status chain broken)');
        }
      }
    }
  }

  // --- questions ------------------------------------------------------------
  const lessonStatus = new Map(lessons.map(function (l) { return [l.lessonId, l.status]; }));
  for (const q of questions) {
    const id = isNonEmptyString(q.questionId) ? q.questionId : '<no questionId>';

    if (QUESTION_TYPES.indexOf(q.type) === -1) {
      errors.push('question ' + id + ': type "' + q.type + '" not in ' + QUESTION_TYPES.join('|'));
    }
    if (!isNonEmptyString(q.lessonId) || !lessonIds.has(q.lessonId)) {
      errors.push('question ' + id + ': lessonId "' + q.lessonId + '" does not exist in lessons.json');
    }
    if (!Array.isArray(q.options) || q.options.length < 1) {
      errors.push('question ' + id + ': must have at least one option');
    } else {
      const optIds = new Set();
      for (const o of q.options) {
        if (!o || !isNonEmptyString(o.id)) { errors.push('question ' + id + ': option missing id'); continue; }
        if (optIds.has(o.id)) errors.push('question ' + id + ': duplicate option id "' + o.id + '"');
        optIds.add(o.id);
      }
      if (!optIds.has(q.correct)) {
        errors.push('question ' + id + ': correct "' + q.correct + '" is not one of the option ids');
      }
    }
    // A question may have an empty source only while its lesson is still a
    // draft (generated quiz awaiting review); published content must cite.
    if (isNonEmptyString(q.source)) {
      if (!sourceIds.has(q.source)) {
        errors.push('question ' + id + ': source "' + q.source + '" does not exist in sources.json');
      }
    } else if (lessonStatus.get(q.lessonId) !== 'draft') {
      errors.push('question ' + id + ': source "' + q.source + '" does not exist in sources.json');
    }
  }

  report(errors, dataDir);
}

function report(errors, dataDir) {
  if (errors.length) {
    console.error('check-course: ' + errors.length + ' error(s) in ' + dataDir);
    for (const e of errors) console.error('  - ' + e);
    process.exit(1);
  }
  console.log('check-course: OK (' + dataDir + ')');
  process.exit(0);
}

main();
