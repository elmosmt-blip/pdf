#!/usr/bin/env node
'use strict';
/*
 * apply-course-images.js — module illustrations.
 *
 * The course renders an undocumented-but-supported content block
 *   { t:'image', src:'assets/img/mNN.png', alt, caption }
 * as a <figure class="fig fig--photo"><img width=1280 height=720>. Only 15 of
 * the 92 lessons carry a figure, and only 10 carry a table, so most lessons
 * have no visual at all. This script attaches one generated illustration to
 * each module-opening lesson, immediately after the lesson's SVG schematic,
 * so the schematic keeps its position and the illustration adds detail.
 *
 * Every illustration is drawn in the course design system extracted from
 * assets/style.css: background #0D1117, single signal teal #53d1cc, slate
 * hairlines, translucent dark glass panels, IBM Plex Mono labels, 1280x720.
 * Each was reviewed against the lesson it illustrates, and any number shown
 * in an illustration is dictated by the MODULES table below so it cannot
 * drift from the lesson text.
 *
 * Usage: node scripts/apply-course-images.js [dataDir]
 */

const fs = require('fs');
const path = require('path');

const dataDir = process.argv[2] ? path.resolve(process.argv[2]) : path.join(__dirname, '..', 'data');
const LESSONS_FILE = path.join(dataDir, 'lessons.json');

// moduleId -> {caption, alt}. The file lives at assets/img/<moduleId>.png.
// Captions stay in the lesson's own language and style, and describe what the
// illustration shows rather than repeating the lesson's numbers.
const MODULES = {
  m01: {
    caption: 'Incoming inspection and the sampling plan: lot definition, inspection level, AQL, code letter, accept and reject numbers',
    alt: 'Incoming inspection sampling plan with a PCB panel grid, a lot label, counterfeit red-flag reels and an accept/reject chart for lot size 5000 at level II, AQL 1.0 percent, code letter L, n equals 200, accept 5, reject 6',
  },
  m02: {
    caption: 'Moisture inside a package: ingress paths, barrier bag with desiccant and humidity indicator card, floor-life clock',
    alt: 'IC package cross-section showing moisture ingress and cracking, a moisture barrier bag with desiccant and HIC, and a floor-life clock showing elapsed hours',
  },
  m03: {
    caption: 'Stencil aperture geometry: area ratio and aspect ratio decide whether paste releases from the aperture',
    alt: 'Stencil aperture cross-section with paste transferring to a pad, and the area ratio and aspect ratio formulas with their minima',
  },
  m04: {
    caption: 'Print cycle: squeegee, snap-off, paste release, then inspection of the deposit',
    alt: 'Screen printer cycle showing squeegee print, stencil snap-off gap, paste release and a deposit inspection scan',
  },
  m05: {
    caption: 'Pick-and-place machine overview: placement accuracy and repeatability, feeder bank, fiducials, axes travel',
    alt: 'Pick-and-place machine with gantry, placement head and nozzles, feeder bank, fiducial marks on a board and an axes travel diagram',
  },
  m06: {
    caption: 'Reflow profile anatomy: ramp, soak, time above liquidus, peak, cooling, against the SAC305 liquidus and solidus',
    alt: 'Reflow thermal profile curve with ramp, soak, time above liquidus, peak and cooling zones, and dashed lines for liquidus 219 C and solidus 217 C',
  },
  m07: {
    caption: 'Inspection layers: what visual, AOI, 2D X-ray, laminar 3D and boundary scan can each see',
    alt: 'Stack of five inspection layers showing visual, AOI, 2D X-ray of a BGA with voids, laminar 3D tomographic slice and a boundary scan chain',
  },
  m08: {
    caption: 'Through-hole joint cross-section: barrel fill, annular ring, and the mechanical load that keeps through-hole in the design',
    alt: 'Through-hole solder joint cross-section with barrel fill and annular ring callouts, and a connector under mechanical load',
  },
};

function note(msg) { console.log('  ' + msg); }

function main() {
  console.log('apply-course-images: dataDir=' + dataDir);
  const lessons = JSON.parse(fs.readFileSync(LESSONS_FILE, 'utf8'));
  let added = 0;

  for (const moduleId of Object.keys(MODULES)) {
    const lessonId = moduleId + 'l01';
    const lesson = lessons.find(function (l) { return l.lessonId === lessonId; });
    if (!lesson) throw new Error('lesson not found: ' + lessonId);
    const meta = MODULES[moduleId];

    const src = 'assets/img/' + moduleId + '.png';
    const file = path.join(dataDir, '..', 'assets', 'img', moduleId + '.png');
    if (!fs.existsSync(file)) throw new Error('missing image file: ' + file);

    // Find the theory section that carries the lesson's SVG figure.
    let section = null;
    for (const t of (lesson.content.theory || [])) {
      if (t && typeof t === 'object' && Array.isArray(t.blocks) &&
          t.blocks.some(function (b) { return b && b.t === 'figure'; })) {
        section = t;
        break;
      }
    }
    if (!section) throw new Error('no figure-bearing theory section in ' + lessonId);

    const already = section.blocks.some(function (b) {
      return b && b.t === 'image' && b.src === src;
    });
    if (already) {
      note('skip ' + lessonId + ' (image already attached)');
      continue;
    }

    const figIndex = section.blocks.findIndex(function (b) { return b && b.t === 'figure'; });
    section.blocks.splice(figIndex + 1, 0, {
      t: 'image',
      src: src,
      alt: meta.alt,
      caption: meta.caption,
    });
    note('attach ' + src + ' -> ' + lessonId + ' theory[' +
      (lesson.content.theory.indexOf(section)) + '].blocks[' + (figIndex + 1) + ']');
    added++;
  }

  if (added === 0) {
    note('nothing to do — every image is already attached');
    return;
  }
  fs.writeFileSync(LESSONS_FILE, JSON.stringify(lessons, null, 2) + '\n', 'utf8');
  console.log('apply-course-images: attached ' + added + ' image(s).');
}

try { main(); } catch (e) {
  console.error('apply-course-images: FAILED — ' + e.message);
  process.exit(1);
}
