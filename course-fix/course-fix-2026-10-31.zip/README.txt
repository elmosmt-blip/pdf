SMT & THT Process Engineer — fixes bundle (31.10.2026)
=====================================================

Contains the reviewed fixes to course data. Full changelog with sources and
verification output: COURSE_FIXES.md (in the analysis repo).

FILES
  scripts/apply-review-fixes.js   patcher (idempotent, writes .bak backups)
  scripts/gates.js                new publication gates + TBD burn-down report
  data/lessons.fixed.json         12 lessons changed
  data/questions.fixed.json       154 competency tags fixed, 3 questions added
  data/sources.fixed.json         source registry 5 -> 14
  assets/data-embed.fixed.js      regenerated file:// copy

APPLY (option A - recommended, keeps backups and prints the changes)
  cp scripts/apply-review-fixes.js <course>/scripts/
  cp scripts/gates.js              <course>/scripts/
  cd <course>
  node scripts/apply-review-fixes.js     # patches data/*.json in place
  node scripts/embed.js                  # regenerates assets/data-embed.js
  node scripts/check-course.js           # their checker  -> must print OK
  node scripts/gates.js                  # new gates      -> must print OK

APPLY (option B - copy the fixed files directly)
  cp data/lessons.fixed.json     <course>/data/lessons.json
  cp data/questions.fixed.json   <course>/data/questions.json
  cp data/sources.fixed.json     <course>/data/sources.json
  cp assets/data-embed.fixed.js  <course>/assets/data-embed.js

IMPORTANT: assets/data-embed.js must be replaced too. When index.html is
opened from file:// the runtime reads the embedded copy, not data/*.json —
without this step the course keeps showing the old content.

NOT CHANGED ON PURPOSE
  lesson statuses stay "draft" and TBD-REVIEW markers stay in place:
  promotion to factchecked/reviewed/published is a human reviewer action.
